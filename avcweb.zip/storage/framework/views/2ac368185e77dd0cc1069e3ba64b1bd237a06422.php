<?php $__env->startSection("head-beg"); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/AVC-Tech/MarkDownToHtml@1.0.0/markdown.css" type="text/css" media="all" />
<script src="https://cdn.jsdelivr.net/gh/AVC-Tech/MarkDownToHtml@1.0.0/markdown.js" type="text/javascript" charset="utf-8"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("head"); ?>
<link rel="stylesheet" href="/static/css/projects/item_view.css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("body"); ?>
<div class="item-container">
	<div class="head">
		<div class="image-bg">
			<img src="<?php if($project->image != null): ?> <?php echo e($project->image); ?> <?php else: ?> /static/images/backgrounds/project_defaults/bg1.jpg <?php endif; ?> "/>
		</div>
		<div class="head-content">
			<div class="cont"><div>
			<h2 class="item-name"><?php echo e($project->name); ?></h2>
			<h6 class="item-author">by <?php echo e($project->author); ?></h6>
			</div></div>
		</div>
	</div>
	<div class="content">
	<div class="description">
		<p><?php echo e($project->description); ?></p>
		<?php if($project->single_item_project): ?>
		<a href="/projects/<?php echo e($project->project_id); ?>/<?php echo e($project->latestItem->item_id); ?>">Go to item</a>
		<?php else: ?>
		
		<?php endif; ?>
	</div>
	<div class="details">
		<table class="table">
			<tbody>
				<?php $__currentLoopData = array_keys(json_decode($project->details,true)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($x); ?></td>
					<td><?php echo e(json_decode($project->details,true)[$x]); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	<div class="readme-head">
			README
		</div>
	<div style="width: calc(100% - 30px);margin: 15px;" class="readme">
		
		<?php echo $project->readme; ?>

	</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script-onscroll"); ?>
if(window.scrollY >= 50) showTopBar();
else hideTopBar();
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/emulated/0/website/avcweb/resources/views/projects/project_view.blade.php ENDPATH**/ ?>