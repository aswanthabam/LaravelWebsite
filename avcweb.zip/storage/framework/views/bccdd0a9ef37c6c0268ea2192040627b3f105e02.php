<?php $__env->startSection("head"); ?>
<link rel="stylesheet" href="/static/css/admin/index.css"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("body"); ?>
<div class="projects">
<h2>Projects</h2>
<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="project">
  <div class="head col-12">
    <h5><?php echo e($pro->name); ?></h5>
    <small><?php echo e($pro->project_id); ?></small><br/>
    <small>Created on : <?php echo e($pro->added_on); ?></small>
    <small>Updated on : <?php echo e($pro->changed_on); ?></small>
    <?php if($pro->single_item_project): ?> 
    <div class="col-12">
      Latest : <?php if($pro->latestItem != null): ?> <a href="/admin/view/project/<?php echo e($pro->project_id); ?>/item/<?php echo e($pro->latestItem->item_id); ?>"><?php echo e($pro->latestItem->release_name); ?></a> <?php else: ?> <a href="/admin/add/project/<?php echo e($pro->project_id); ?>/item">New release</a> <?php endif; ?>
    </div>
    <?php else: ?>
    <p>
      Project has multiple <button class="btn btn-light" type="button" data-bs-toggle="collapse" data-bs-target="#collapseItems<?php echo e($pro->id); ?>" aria-expanded="false" aria-controls="collapseItems<?php echo e($pro->id); ?>">
        Items <i class="bi bi-chevron-down"></i>
      </button>
    </p>
    <div class="collapse" id="collapseItems<?php echo e($pro->id); ?>">
      <div class="card card-body">
        <?php if(count($pro->multi) > 0): ?>
        <?php $__currentLoopData = $pro->multi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $multi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card card-body">
          <h4><?php echo e($multi->name); ?></h4>
          <?php if($multi->item()->where("is_latest",true)->first() == null): ?>
          No items added <a href="/admin/add/project/<?php echo e($pro->project_id); ?>/multi/<?php echo e($multi->id); ?>/item" class="btn btn-light">Add</a>
          <?php else: ?>
          <p>
            <small><?php echo e($multi->item()->where("is_latest",true)->first()->release_name); ?></small><br/>
            <a href="/admin/add/project/<?php echo e($pro->project_id); ?>/multi/<?php echo e($multi->id); ?>/item" class="btn btn-light">Update</a>
            <a href="/admin/edit/project/<?php echo e($pro->project_id); ?>/multi/<?php echo e($multi->id); ?>/item/<?php echo e($multi->item()->where("is_latest",true)->first()->item_id); ?>" class="btn btn-light">Edit</a>
          </p>
          <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="card card-body"><center><a href="/admin/add/project/<?php echo e($pro->project_id); ?>/multi" class="btn btn-light">Create New</a></center></div>
        <?php else: ?>
        <div class="card card-body"><center>No items found <br/><a href="/admin/add/project/<?php echo e($pro->project_id); ?>/multi" class="btn btn-light">Create New</a></center></div>
        <?php endif; ?>
      </div>
    </div>

    <?php endif; ?>
  </div>
  <div class="options col-12">
    <a href="/admin/view/project/<?php echo e($pro->project_id); ?>" class="btn btn-light">More</a>
    <a href="/projects/<?php echo e($pro->project_id); ?>" class="btn btn-light">View</a>
     <a href="/admin/add/project/<?php echo e($pro->project_id); ?>/item" class="btn btn-light"> <?php if($pro->single_item_project): ?> Update <?php else: ?> New <?php endif; ?> </a>
     <a href="/admin/edit/project/<?php echo e($pro->project_id); ?>" class="btn btn-light">Edit</a>
     <a href="/admin/delete/project/<?php echo e($pro->project_id); ?>" class="btn btn-danger">Delete</a>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme/admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/emulated/0/website/avcweb/resources/views/admin/projects.blade.php ENDPATH**/ ?>