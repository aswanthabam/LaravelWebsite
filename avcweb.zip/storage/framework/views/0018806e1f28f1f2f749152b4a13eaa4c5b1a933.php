<?php $__env->startSection("head"); ?>
	<link rel="stylesheet" href="/static/css/form/form-style.css"/>
	<style>
	.main{
		margin: 0 !important;
		padding: 0 !important;
	}
		.table{
			width: 100%;
			background: #fff;
		}
		.table td{
			padding: 5px;
			border: 1px solid #12121290;
		}
		.table .head{
			background: #12121290;
			color: #fff;
		}
		.table .head td{
			border: 1px solid #fff;
		}
		.topbar{
			box-shadow: none;
			background: #fff;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("body"); ?>
<?php if($project->single_item_project): ?>
<center><h4><?php if(isset($edit)): ?>Edit <?php endif; ?> <?php if(empty($edit)): ?> Add <?php endif; ?> a version</h4></center>
<?php else: ?>
<center><h4>Add an Item to project</h4></center>
<?php endif; ?>
<form class="form-control" method="post" action="
<?php if(empty($edit)): ?>
/admin/add/project/<?php echo e($project_id); ?>

<?php if(isset($multi)): ?>
/multi/<?php echo e($multi->multi_id); ?>

<?php endif; ?>
/item
<?php endif; ?>
<?php if(isset($edit)): ?>
/admin/edit/project/<?php echo e($project->project_id); ?>

<?php if(isset($multi)): ?>
/multi/<?php echo e($multi->multi_id); ?>

<?php endif; ?>
/item/<?php echo e($item->item_id); ?>

<?php endif; ?>
">
	<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
	<?php echo csrf_field(); ?>
	<?php if(!$project->single_item_project): ?>
	<div class="form-group">
		<label for="name">Item Name</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($item->name); ?>" <?php endif; ?> type="text" name="name" placeholder="Item Name"/>
	</div>
	<?php endif; ?>
	<div class="form-group">
		<label for="version">Release Name *</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($item->release_name); ?>" <?php endif; ?> type="text" name="release_name" placeholder="Release" required/>
	</div>
	<div class="form-group">
		<label for="version">Item Version *</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($item->version_name); ?>" <?php endif; ?> type="text" name="version" placeholder="Version" required/>
	</div>
	
	<div class="form-group">
		<label for="description">Item Description *</label>
		<input type="text" name="description" placeholder="Description" value="<?php if(empty($edit)): ?> <?php echo e($project->description); ?> <?php endif; ?> <?php if(isset($edit)): ?> <?php echo e($item->description); ?> <?php endif; ?> " required/>
	</div>
	<div class="form-group">
		<label for="author">Item Author</label>
		<input type="text" name="author" placeholder="Author" value="<?php if(empty($edit)): ?> <?php echo e($project->author); ?> <?php endif; ?> <?php if(isset($edit)): ?> <?php echo e($item->author); ?> <?php endif; ?> "/>
	</div>
	<div class="form-group">
		<label for="author_link">Author Link</label>
		<input type="text" name="author_link" placeholder="Author Link" value="<?php if(empty($edit)): ?> <?php echo e($project->author_link); ?> <?php endif; ?> <?php if(isset($edit)): ?> <?php echo e($item->author_link); ?> <?php endif; ?> "/>
	</div>
	<div class="form-group">
		<label for="created_date">Created Date</label>
		<input class="form-item-sided" id="created_date_cont" type="text" name="created_date" placeholder="Created Date" value="<?php if(empty($edit)): ?> <?php echo e($project->created_at); ?> <?php endif; ?> <?php if(isset($edit)): ?> <?php echo e($item->created_at); ?> <?php endif; ?> "/>
		<input class="form-item-sided-cont" id="created_date" type="date"/>
	</div>
	<div class="form-group">
		<input checked type="checkbox" name="is_latest" value="1"/>
		<label for="is_latest" <?php if(isset($edit)): ?> <?php if($item->latest): ?> checked <?php endif; ?> <?php endif; ?>>Is Latest *</label>
	</div>
	<div class="form-group">
		<input <?php if(empty($edit)): ?> checked <?php endif; ?> <?php if(isset($edit)): ?> <?php if($item->downloadable): ?> checked <?php endif; ?> <?php endif; ?> onchange="isDownloadable(this)" type="checkbox" name="is_downloadable" value="1"/>
		<label for="is_downloadable">Is Downloadable *</label>
	</div>
	<div id="download_link" style="display:block" class="form-group">
		<label for="download_link">Download Link</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($item->download_link); ?>" <?php endif; ?> type="text" name="download_link" placeholder="download_link"/>
	</div>
	<div class="form-group">
		<input <?php if(empty($edit)): ?> checked <?php endif; ?> <?php if(isset($edit)): ?> <?php if($item->viewable): ?> checked <?php endif; ?> <?php endif; ?> onchange="isViewable(this)" type="checkbox" name="is_viewable" value="1"/>
		<label for="is_viewable">Is Viewable *</label>
	</div>
	<div id="view_link" style="display:block"class="form-group">
		<label for="view_link">View Link</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($item->view_link); ?>" <?php endif; ?> type="text" name="view_link" placeholder="view_link"/>
	</div>
	<div class="form-group">
		<label for="readme">Description HTML</label>
		<textarea type="text" name="readme" placeholder="Description HTML"><?php if(empty($edit)): ?> <?php if($project->single_item_project): ?><?php echo e($project->readme); ?> <?php endif; ?> <?php endif; ?> <?php if(isset($edit)): ?> <?php echo e($item->readme); ?> <?php endif; ?> </textarea>
	</div>
	<div class="form-group">
		<label for="keywords">Platform</label>
		<input type="text" name="platform" placeholder="Platform" value="<?php if(empty($edit)): ?> <?php echo e($project->platform); ?> <?php endif; ?> <?php if(isset($edit)): ?> <?php echo e($item->platform); ?> <?php endif; ?> "/>
	</div>
	<div class="form-group">
		<label for="image">Image Link</label>
		<input type="text" name="image" placeholder="Link" value="<?php if(empty($edit)): ?> <?php echo e($project->image); ?> <?php endif; ?> <?php if(isset($edit)): ?> <?php echo e($item->image); ?> <?php endif; ?> "/>
	</div>
	<div class="form-group">
		<label for="keywords">Keywords (Use ',' to seperate)</label>
		<input type="text" name="keywords" placeholder="Keywords" value="<?php if(empty($edit)): ?> <?php echo e($project->keywords); ?> <?php endif; ?> <?php if(isset($edit)): ?> <?php echo e($item->keywords); ?> <?php endif; ?> "/>
	</div>
	<div class="form-group">
		<label for="details">Other Details</label>
		<input id="details-cont" type="text" name="details" value="<?php if(empty($edit)): ?> <?php echo e($project->details); ?> <?php endif; ?> <?php if(isset($edit)): ?> <?php echo e($item->details); ?> <?php endif; ?> " hidden/>
		<table style="display:none" id="details-items" class="table">
			<tr class="head">
				<td>Key</td>
				<td>Value</td>
			</tr>
		</table>
		<div>
			<input id="key" style="width: calc(50% - 10px)" type="text" placeholder="Key"/>
	    	<input id="value" style="width: calc(50% - 10px)" placeholder="Value"/>
	    	<input style="position: relative; background: #12121290;color: #fff;width: 100px;right: 10px;" value="Add"onclick="addData(this)" type="button"/>
	    </div>
	</div>
	<input type="submit" value="Submit"/>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
otherDetails = {}
init();
function init()
{
   var item = document.getElementById("details-items")
   var cont = document.getElementById("details-cont")
	otherDetails = JSON.parse(cont.value);
	if(Object.keys(otherDetails).length > 0) item.style.display="table";
	for (var x in otherDetails){
	   var tr = document.createElement("tr");
   var elem = document.createElement("td");
   var elem2 = document.createElement("td");
   elem.textContent = x;
   elem2.textContent = otherDetails[x];
   tr.appendChild(elem)
   tr.appendChild(elem2)
   item.appendChild(tr)
	}
}
function addData(elem)
{
   var key = document.getElementById("key")
   var item = document.getElementById("details-items")
   var cont = document.getElementById("details-cont")
   var value = document.getElementById("value")
   item.style.display="table";
   var tr = document.createElement("tr");
   var elem = document.createElement("td");
   var elem2 = document.createElement("td");
   elem.textContent = key.value;
   elem2.textContent = value.value;
   tr.appendChild(elem)
   tr.appendChild(elem2)
   item.appendChild(tr)
   otherDetails[key.value] = value.value;
   cont.value = JSON.stringify(otherDetails);
   key.value = "";
   value.value = "";
}
function isDownloadable(elem)
{
    if(elem.checked)
    {
        document.getElementById("download_link").style.display = "block";
    }
    else{
        document.getElementById("download_link").style.display = "none";
    }
}
function isViewable(elem)
{
    if(elem.checked)
    {
        document.getElementById("view_link").style.display = "block";
    }
    else{
        document.getElementById("view_link").style.display = "none";
    }
}
function setDatePiker()
{
	picker = document.getElementById("created_date");
	cont = document.getElementById("created_date_cont");
	
	cont.onfocus = function (e)
	{
		picker.click();
	}
	picker.onchange = function()
	{
		cont.value = picker.value;
		picker.value = "";
	}
	cont.onchange = function()
	{
		alert(new Date(cont.value))
	}
}

setDatePiker();
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/emulated/0/website/avcweb/resources/views/admin/form/create_item.blade.php ENDPATH**/ ?>