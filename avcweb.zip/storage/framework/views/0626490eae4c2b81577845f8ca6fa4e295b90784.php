<?php $__env->startSection("head"); ?>
	<link rel="stylesheet" href="/static/css/form/form-style.css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("body"); ?>
<?php if($project->single_item_project): ?>
<center><h4>This is a single item project. This project cant contain a multi item enviornment.</h4></center>
<?php else: ?>
<center><h4><?php if(isset($edit)): ?> Edit multi <?php endif; ?> <?php if(empty($edit)): ?> Add <?php endif; ?> Item</h4></center>
<?php endif; ?>
<?php if(!$project->single_item_project): ?>
<form class="form-control" method="post" action="
<?php if(empty($edit)): ?>
/admin/add/project/<?php echo e($project->project_id); ?>/multi
<?php endif; ?>
<?php if(isset($edit)): ?>
/admin/edit/project/<?php echo e($project->project_id); ?>/multi/<?php echo e($multi->multi_id); ?>

<?php endif; ?>
">
	<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
  <?php endif; ?>
	<?php echo csrf_field(); ?>
	<div class="form-group">
		<label for="name">Name *</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($multi->name); ?>" <?php endif; ?> type="text" name="name" placeholder="Name" required/>
	</div>
	<input type="submit" value="Next >>"/>
</form>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/emulated/0/website/avcweb/resources/views/admin/form/add_multi.blade.php ENDPATH**/ ?>