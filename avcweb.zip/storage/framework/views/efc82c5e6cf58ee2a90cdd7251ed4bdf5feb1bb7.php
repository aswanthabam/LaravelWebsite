<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="/static/css/form/form-style.css"/>
<style>
.body-background
{
    display: none;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("body"); ?>
<form class="form-control" action="authenticate" method="post">
	<center><h3>Login</h3></center>
	<?php echo csrf_field(); ?>
	<input name="email" placeholder="Enter e-mail or username"/>
	<input type="password" name="password" placeholder="Password"/>
	<div class="form-group">
	<input type="checkbox" name="remember_me"/>
	<label for="remember_me">Remember Me</label>
	</div>
	<input type="submit" value="Login"/>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/emulated/0/website/avcweb/resources/views/admin/login.blade.php ENDPATH**/ ?>