<?php $__env->startSection("head"); ?>
	<link rel="stylesheet" href="/static/css/form/form-style.css"/>
	<style>
	.main{
		margin: 0 !important;
		padding: 0 !important;
	}
		.table{
			width: 100%;
			background: #fff;
		}
		.table td{
			padding: 5px;
			border: 1px solid #12121290;
		}
		.table .head{
			background: #12121290;
			color: #fff;
		}
		.table .head td{
			border: 1px solid #fff;
		}
		.topbar{
			box-shadow: none;
			background: #fff;
		}
	</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection("brand-name"); ?>
Admin Panel
<?php $__env->stopSection(); ?>
<?php $__env->startSection("body"); ?>
<center><h4><?php if(empty($edit)): ?>Add a new project <?php endif; ?> <?php if(isset($edit)): ?>Edit Project <?php endif; ?> </h4></center>
<form id="form" class="form-control" method="post" action="<?php if(empty($edit)): ?>/admin/add/project <?php endif; ?> <?php if(isset($edit)): ?>/admin/edit/project/<?php echo e($project->project_id); ?><?php endif; ?>">
	<div id="alert-error"style="display:<?php if($errors->any()): ?>block;<?php else: ?> none;<?php endif; ?>" class="alert alert-danger">
        <ul id="errors">
        	<?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
    </div>
	<?php echo csrf_field(); ?>
	
	<?php if(empty($edit)): ?>
	<div class="form-group">
		<label for="project_id">Project ID *</label>
		<input onchange="idEvaluate(this)" type="text" name="project_id" placeholder="Project ID" required/>
	</div>
	<?php endif; ?>
	<div class="form-group">
		<label for="name">Project Name *</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($project->name); ?>" <?php endif; ?> type="text" name="name" placeholder="Project Name" required/>
	</div>
	<div class="form-group">
		<label for="version">Project Version *</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($project->version_name); ?>" <?php endif; ?> type="text" name="version" placeholder="Version" required/>
	</div>
	<div class="form-group">
		<label for="description">Project Description *</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($project->description); ?>" <?php endif; ?> type="text" name="description" placeholder="Description" required/>
	</div>
	<div class="form-group">
		<label for="author">Project Author</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($project->author); ?>" <?php endif; ?> type="text" name="author" placeholder="Author"/>
	</div>
	<div class="form-group">
		<label for="author_link">Author URL</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($project->author_link); ?>" <?php endif; ?> type="text" name="author_link" placeholder="Author Link"/>
	</div>
	<div class="form-group">
		<label for="created_date">Created Date</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($project->created_at); ?>" <?php endif; ?> class="form-item-sided" id="created_date_cont" type="text" name="created_date" placeholder="Created Date"/>
		<input class="form-item-sided-cont" id="created_date" type="date"/>
	</div>
	<div class="form-group">
		<input <?php if(isset($edit)): ?> <?php if($project->single_item_project): ?> checked <?php endif; ?> <?php endif; ?> type="checkbox" name="single_item_project" value="1"/>
		<label for="single_item_project">Single Item Project *</label>
	</div>
	<div class="form-group">
		<label for="readme">Description HTML</label>
		<textarea type="text" name="readme" placeholder="Description HTML"><?php if(isset($edit)): ?><?php echo e($project->readme); ?><?php endif; ?></textarea>
	</div>
	<div class="form-group">
		<label for="keywords">Keywords (Use ',' to seperate)</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($project->keywords); ?>" <?php endif; ?> type="text" name="keywords" placeholder="Keywords"/>
	</div>
	<div class="form-group">
		<label for="platform">Platform</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($project->platform); ?>" <?php endif; ?> type="text" name="platform" placeholder="platform"/>
	</div>
	<div class="form-group">
		<label for="image">Project Image</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($project->image); ?>" <?php endif; ?> type="text" name="image" placeholder="Image url"/>
	</div>
	<div class="form-group">
		<label for="details">Other Details</label>
		<input <?php if(isset($edit)): ?> value="<?php echo e($project->details); ?>" <?php endif; ?> id="details-cont" type="text" name="details" hidden/>
		<table style="display:<?php if(empty($edit)): ?> none <?php endif; ?> <?php if(isset($edit)): ?> table <?php endif; ?>" id="details-items" class="table">
			<tr class="head">
				<td>Key</td>
				<td>Value</td>
			</tr>
		</table>
		<div>
			<input id="key" style="width: calc(50% - 10px)" type="text" placeholder="Key"/>
	    	<input id="value" style="width: calc(50% - 10px)" placeholder="Value"/>
	    	<input style="position: relative; background: #12121290;color: #fff;width: 100px;right: 10px;" value="Add"onclick="addData(this)" type="button"/>
	    </div>
	</div>
	
	<input id="submit" type="submit" value="Submit"/>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
otherDetails = {}
init();
function init()
{
   var item = document.getElementById("details-items")
   var cont = document.getElementById("details-cont")
	otherDetails = JSON.parse(cont.value);
	if(Object.keys(otherDetails).length > 0) item.style.display="table";
	for (var x in otherDetails){
	   var tr = document.createElement("tr");
   var elem = document.createElement("td");
   var elem2 = document.createElement("td");
   elem.textContent = x;
   elem2.textContent = otherDetails[x];
   tr.appendChild(elem)
   tr.appendChild(elem2)
   item.appendChild(tr)
	}
}
function idEvaluate(elem)
{
    var form = document.getElementById("form");
    var submit = document.getElementById("submit");
    var errors = document.getElementById("errors");
    var alertError = document.getElementById("alert-error");
    if(elem.value.includes(" ") || elem.value.includes("/") || elem.value.includes("&") || elem.value.includes("?") || elem.value.includes(".") || elem.value.includes("#"))
    {
        form.disabled = true;
        submit.style.display = "none";
        alertError.style.display = "block";
        errors.innerHTML += "<li>Cannot use space and special characters ('&','/','#' etc) in Project Id</li>";
    }
    else 
    {
        form.disabled = false;
        submit.style.display = "block";
        alertError.style.display = "none";
        errors.innerHTML = "";
    }
    elem.value = elem.value.toLowerCase();
}

function addData(elem)
{
   var key = document.getElementById("key")
   var item = document.getElementById("details-items")
   var cont = document.getElementById("details-cont")
   var value = document.getElementById("value")
   item.style.display="table";
   var tr = document.createElement("tr");
   var elem = document.createElement("td");
   var elem2 = document.createElement("td");
   elem.textContent = key.value;
   elem2.textContent = value.value;
   tr.appendChild(elem)
   tr.appendChild(elem2)
   item.appendChild(tr)
   otherDetails[key.value] = value.value;
   cont.value = JSON.stringify(otherDetails);
   key.value = "";
   value.value = "";
}
function setDatePiker()
{
	picker = document.getElementById("created_date");
	cont = document.getElementById("created_date_cont");
	
	cont.onfocus = function (e)
	{
		picker.click();
	}
	picker.onchange = function()
	{
		cont.value = picker.value;
		picker.value = "";
	}
	cont.onchange = function()
	{
		alert(new Date(cont.value))
	}
}
setDatePiker();
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/emulated/0/website/avcweb/resources/views/admin/form/create_project.blade.php ENDPATH**/ ?>