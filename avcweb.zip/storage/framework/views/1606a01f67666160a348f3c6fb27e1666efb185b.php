<?php $__env->startSection("head"); ?>
<link rel="stylesheet" href="/static/css/projects/all_projects.css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("body"); ?>
<div class="projects">
  <div class="head">
		<div class="image-bg">
			<img src="/static/images/backgrounds/project_defaults/bg1.jpg"/>
		</div>
		<div class="head-content">
			<div class="cont"><div>
			<h2 class="item-name">Projects</h2>
			<h6 class="item-release"></h6>
			</div></div>
		</div>
	</div>
  <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="item">
    <div class="head">
      <h4><?php echo e($pro->name); ?></h4>
    </div>
    <div class="content">
      <p><?php echo e($pro->description); ?></p>
    </div>
    <div class="more"><a href="/projects/<?php echo e($pro->project_id); ?>">View More >></a></div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script-onscroll"); ?>
if(window.scrollY >= 50) showTopBar();
else hideTopBar();
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/emulated/0/WebSite/avcweb/resources/views/projects/all_projects.blade.php ENDPATH**/ ?>