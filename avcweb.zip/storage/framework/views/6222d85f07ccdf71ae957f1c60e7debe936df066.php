<?php $__env->startSection("head"); ?>
<link rel="stylesheet" href="/static/css/admin/view/project_view.css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("body"); ?>
<?php if($project->single_item_project): ?>
<?php $__currentLoopData = $project->allItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($item->is_latest): ?>
Latest
<?php endif; ?>
<div class="item">
  
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/emulated/0/website/avcweb/resources/views/admin/view/project_view.blade.php ENDPATH**/ ?>