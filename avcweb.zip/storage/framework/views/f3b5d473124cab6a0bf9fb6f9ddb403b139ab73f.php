<?php $__env->startSection("sidebar-cont"); ?>
<a class="sidebar-item" href="/admin/projects"><i class="bi bi-person-workspace"></i> <span class="full">Projects</span></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("sidebar-top"); ?>
<img width="100%" src="/static/images/icons/icon_transparent.png"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("sidebar-bottom"); ?>
<a class="bottom-item" href="/logout"><i class="bi bi-box-arrow-left"></i> <span class="full">Logout</span></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("body"); ?>
<h5><b>Welcome <?php echo e($user->name); ?></b></h5>
<a href="/admin/add/project">Add new project</a>
<h4>Projects</h4>
<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($pro->name); ?> <?php echo e($pro->version); ?> <?php echo e($pro->created_date); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme/admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/emulated/0/WebSite/avcweb/resources/views/admin/index.blade.php ENDPATH**/ ?>